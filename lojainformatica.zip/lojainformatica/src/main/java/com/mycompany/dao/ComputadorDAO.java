/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.dao;

import com.mycompany.model.Computador;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 * Esta classe é responsável por interagir com o banco de dados para operações relacionadas a objetos Computador.
 *
 * @author RodrigoAnjos2004
 */
public class ComputadorDAO {

    // Definição de variáveis de conexão com o banco de dados
    public static String path = "com.mysql.cj.jdbc.Driver";
    public static String url = "jdbc:mysql://localhost/ado";
    public static String lgn = "root";
    public static String pwd = "";

    /**
     * Método para salvar um objeto Computador no banco de dados.
     *
     * @param obj O objeto Computador a ser salvo.
     * @return true se a operação for bem-sucedida, caso contrário false.
     */
    public static boolean salvar(Computador obj) {

        boolean retorno = false;
        Connection connect = null;

        try {
            // Carrega o driver JDBC
            Class.forName(path);

            // Estabelece uma conexão com o banco de dados
            connect = DriverManager.getConnection(url, lgn, pwd);

            // Prepara uma declaração SQL para inserção de um novo registro na tabela "computador"
            PreparedStatement cmdSQL = connect.prepareStatement("INSERT INTO computador(marca, hd, processador) VALUES (?, ?, ?);", Statement.RETURN_GENERATED_KEYS);

            // Define os valores dos parâmetros na declaração SQL
            cmdSQL.setString(1, obj.getMarca());
            cmdSQL.setString(2, obj.getHd());
            cmdSQL.setString(3, obj.getProcessador());

            // Executa a declaração SQL
            int rows = cmdSQL.executeUpdate();
            if (rows > 0) {
                retorno = true;

                // Recupera a chave gerada automaticamente (ID) após a inserção
                ResultSet rs = cmdSQL.getGeneratedKeys();
                if (rs != null) {
                    if (rs.next()) {
                        obj.setId(rs.getInt(1));
                    }
                }
            }

        } catch (ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        return retorno;
    }

    /**
     * Método para listar todos os objetos Computador no banco de dados.
     *
     * @return Uma lista de objetos Computador.
     */
    public static ArrayList<Computador> listar() {

        Connection connect = null;
        ArrayList<Computador> lista = new ArrayList<Computador>();

        try {
            // Carrega o driver JDBC
            Class.forName(path);

            // Estabelece uma conexão com o banco de dados
            connect = DriverManager.getConnection(url, lgn, pwd);

            // Prepara uma declaração SQL para selecionar todos os registros da tabela "computador"
            PreparedStatement cmdSQL = connect.prepareStatement("select * from computador;");

            // Executa a consulta SQL
            ResultSet rs = cmdSQL.executeQuery();

            if (rs != null) {
                while (rs.next()) {
                    Computador objNew = new Computador();
                    objNew.setId(rs.getInt("id"));
                    objNew.setMarca(rs.getString("marca"));
                    objNew.setHd(rs.getString("hd"));
                    objNew.setProcessador(rs.getString("processador"));

                    lista.add(objNew);
                }
            }
        } catch (ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        return lista;
    }

    /**
     * Método para buscar um objeto Computador por ID no banco de dados.
     *
     * @param id O ID do objeto a ser buscado.
     * @return O objeto Computador encontrado.
     */
    public static Computador buscarPorId(int id) {

        Connection connect = null;
        Computador obj = new Computador();

        try {
            // Carrega o driver JDBC
            Class.forName(path);

            // Estabelece uma conexão com o banco de dados
            connect = DriverManager.getConnection(url, lgn, pwd);

            // Prepara uma declaração SQL para selecionar um registro da tabela "computador" por ID
            PreparedStatement cmdSQL = connect.prepareStatement("SELECT * FROM computador WHERE id = ?;");
            cmdSQL.setInt(1, id);

            // Executa a consulta SQL
            ResultSet rs = cmdSQL.executeQuery();

            if (rs != null) {
                while (rs.next()) {
                    obj.setId(rs.getInt("id"));
                    obj.setMarca(rs.getString("marca"));
                    obj.setHd(rs.getString("hd"));
                    obj.setProcessador(rs.getString("processador"));
                }
            }

        } catch (ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        return obj;
    }

    /**
     * Método para buscar objetos Computador por processador no banco de dados.
     *
     * @param processador O processador a ser usado como critério de busca.
     * @return Uma lista de objetos Computador encontrados.
     */
    public static ArrayList<Computador> buscarPorProcessador(String processador) {

        Connection connect = null;
        ArrayList<Computador> lista = new ArrayList<Computador>();

        try {
            // Carrega o driver JDBC
            Class.forName(path);

            // Estabelece uma conexão com o banco de dados
            connect = DriverManager.getConnection(url, lgn, pwd);

            // Prepara uma declaração SQL para selecionar registros da tabela "computador" por processador
            PreparedStatement cmdSQL = connect.prepareStatement("SELECT * FROM computador WHERE processador = ?;");
            cmdSQL.setString(1, processador);

            // Executa a consulta SQL
            ResultSet rs = cmdSQL.executeQuery();

            if (rs != null) {
                while (rs.next()) {
                    Computador objNew = new Computador();
                    objNew.setId(rs.getInt("id"));
                    objNew.setMarca(rs.getString("marca"));
                    objNew.setHd(rs.getString("hd"));
                    objNew.setProcessador(rs.getString("processador"));
                    
                    lista.add(objNew);
                }
            }

        } catch (ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        return lista;
    }

    /**
     * Método para alterar um objeto Computador no banco de dados.
     *
     * @param obj O objeto Computador a ser alterado.
     * @return true se a operação for bem-sucedida, caso contrário false.
     */
    public static boolean alterar(Computador obj) {
        boolean retorno = false;
        Connection connect = null;

        try {
            // Carrega o driver JDBC
            Class.forName(path);

            // Estabelece uma conexão com o banco de dados
            connect = DriverManager.getConnection(url, lgn, pwd);

            // Prepara uma declaração SQL para atualizar um registro na tabela "computador"
            PreparedStatement cmdSQL = connect.prepareStatement("update computador set hd = ?, processador = ? where id = ?;");

            // Define os valores dos parâmetros na declaração SQL
            cmdSQL.setString(1, obj.getHd());
            cmdSQL.setString(2, obj.getProcessador());
            cmdSQL.setInt(3, obj.getId());

            // Executa a declaração SQL
            int rows = cmdSQL.executeUpdate();
            if (rows > 0) {
                retorno = true;
            }
        } catch (ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        return retorno;
    }

    /**
     * Método para excluir um objeto Computador do banco de dados.
     *
     * @param id O ID do objeto a ser excluído.
     * @return true se a operação for bem-sucedida, caso contrário false.
     */
    public static boolean excluir(int id) {
        boolean retorno = false;
        Connection connect = null;

        try {
            // Carrega o driver JDBC
            Class.forName(path);

            // Estabelece uma conexão com o banco de dados
            connect = DriverManager.getConnection(url, lgn, pwd);

            // Prepara uma declaração SQL para excluir um registro da tabela "computador" por ID
            PreparedStatement cmdSQL = connect.prepareStatement("delete from computador where id = ?;");

            // Define o valor do parâmetro na declaração SQL
            cmdSQL.setInt(1, id);

            // Executa a declaração SQL
            int rows = cmdSQL.executeUpdate();
            if (rows > 0) {
                retorno = true;
            }
        } catch (ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        return retorno;
    }
}
