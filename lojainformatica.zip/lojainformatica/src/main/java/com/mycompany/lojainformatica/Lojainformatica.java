/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package com.mycompany.lojainformatica;

import javax.swing.SwingUtilities;

public class Lojainformatica {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                TelaConsulta TelaConsulta = new TelaConsulta();
                TelaConsulta.setVisible(true);
            }
        });
    }
}
